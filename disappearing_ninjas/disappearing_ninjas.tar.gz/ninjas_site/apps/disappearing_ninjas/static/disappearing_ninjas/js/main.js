$(document).ready(function(){
  console.log("JavaScript running");
});
