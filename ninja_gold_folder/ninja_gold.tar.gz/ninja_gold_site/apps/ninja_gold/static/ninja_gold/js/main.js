$(document).ready(function(){
  console.log("JavaScript Running");

  $('play').submit(function(){
    $('#activities').html();
  });

});
