$(document).ready(function(){
  console.log('jQuery running!');
  $.get("/", function(res){
    
  });

  $('form').submit(function(){
    console.log('click');
    $.post("/note/create", $(this).serialize(), function(res){
      console.log(res);
      $("#notes").html(res);
    });
    return false;
  });

});
