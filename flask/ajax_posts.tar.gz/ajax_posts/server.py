from flask import Flask, request, render_template, redirect, jsonify
from mysqlconnection import MySQLConnector

app = Flask(__name__)
app.secret_key = 'soindionwef;klnwe;kn'
mysql = MySQLConnector(app, 'notes')

@app.route('/')
def index():
    query = "SELECT * FROM notes"
    notes = mysql.query_db(query)
    return render_template('index.html', notes=notes)

@app.route('/note/json_index')
def json_index():
    query = "SELECT * FROM notes"
    notes = mysql.query_db(query)
    return jsonify(notes=notes)

@app.route('/note/create', methods=['post'])
def create():
    #print(request.form)
    insert_query = """
            INSERT INTO notes (content, created_at, updated_at)
            VALUES (:note, NOW(), NOW())
            """
    insert_data = {
            'note': request.form['note']
            }
    mysql.query_db(insert_query, insert_data)
    return_query = "SELECT * FROM notes"
    notes = mysql.query_db(return_query)
    return render_template('partials/notes.html', notes=notes)

app.run(debug=True)
