$(document).ready(function(){
  console.log("JavaScript Running");
});
